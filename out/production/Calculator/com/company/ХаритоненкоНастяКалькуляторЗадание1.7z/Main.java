package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner calc = new Scanner(System.in);
        double x; double y; double result;

        System.out.println( "Введите первое число: ");
        x = calc.nextDouble();
        System.out.println( "Введите второе число: ");
        y = calc.nextDouble();

        result = x+y;
        System.out.println( "Сумма равна: " + result);

    }
}
